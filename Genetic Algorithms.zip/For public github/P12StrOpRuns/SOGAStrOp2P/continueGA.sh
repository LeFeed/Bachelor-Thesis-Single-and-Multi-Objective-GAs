#!/bin/bash

#script to CONTINUE the GA, run games to get the win-rate (fitness) and then evolve the population
#1st start gen count
#2nd end gen Count
#3nd = size of the Population
#4rd = amount of games to play to calculate the win-rate 
echo "startdate: "$(date)
startdate=$(date)
starttime=`date +%s`
echo "starttime: "$starttime


generationsStart=$1
populationSize=$2
numOfGames=$3
mix_rate=$4
mutation_rate=$5
crossover_rate=$6
elitism_size=$7
secondsLimit=$8 #3 hours = 10800 seconds

#clean old Population (only the newest!) if there are any remains
echo $(python3 "./cleanCurrent.py3" $generationsStart)
generations=$generationsStart
generationsStart=$(($generationsStart+1))


echo "Input Variables: "
echo "Generations Start: "$generationsStart
echo "populationSize: "$populationSize 
echo "numOfGames: "$numOfGames 
echo "mix_rate: "$mix_rate 
echo "mutation_rate: "$mutation_rate 
echo "crossover_rate: "$crossover_rate 
echo "elitism_size: "$elitism_size
echo "secondsLimit: "$secondsLimit



#TODO: these Maybe also as parameters?
agentTrain="python3 players/GAReGr/agent.py "
opponent="./players/Coac/main"



#now perform Selection, Crossover, Mutation and Evaluation of the Fitness
for ((i=$generationsStart; i<=100000;i++))
do

    echo "Evolve in $i th generation.."
    echo -e "\n"

    #Evolve the Population (Produce offspring)
    echo $(python3 "./Evolve.py3" $populationSize $mix_rate $mutation_rate $crossover_rate $elitism_size )
    echo "Evolution finished!"
    echo -e "\n"

    #Evaluate the Offsprings' Fitness

    #play "numOfGames" games to calculate the win-rate (fitness) of each Individual in the Population
    #play half of the games as p1 and the other half as p2

    #use same seeds for every Gen, so that they will be tested with the same drafts and games
    
    echo $("./test-run-games.sh" $numOfGames "$agentTrain" "$opponent" $populationSize 0)






    #Sort the Population according to fitness
    
    echo $(python3 "./sortFitness.py3" $populationSize $((i)))
    echo -e "\n"

    #check if time limit was overstepped
    endtime=`date +%s`
    execution_seconds=$(($endtime - $starttime))
    if [[ $execution_seconds -gt $secondsLimit ]]; then
        echo "$secondsLimit seconds limit passed! Stop loop, no new generations"
        generations=$i
        break
    fi

done

enddate=$(date)

#save our chromosomes and clean our GA directory
#echo $(python3 "./saveAndClean.py3" "$startdate" "$enddate" $generations $populationSize $numOfGames $mix_rate $mutation_rate $crossover_rate $elitism_size)
#echo "\n"
#save our best value according to the 3 best chromosome generation
#echo $(python3 "./helperScripts/getBestMeansTopX.py3" 3 $generations "")

echo "startdate: "$startdate
echo "enddate: "$(date)

echo Execution time was `expr $endtime - $starttime` seconds.

