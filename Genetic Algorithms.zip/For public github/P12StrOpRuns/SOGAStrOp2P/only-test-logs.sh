#!/bin/bash

numOfGames=$1
playerA="$2"
playerB="$3"
seed1Array=$4
seed2Array=$5
selectHalf=$6


wins=0
#TODO: if condition to seperate first and second half of the random array-

Seeds1=($(python3 generateSeeds.py3 $numOfGames | tr -d '[],'))
Seeds2=($(python3 generateSeeds.py3 $numOfGames | tr -d '[],'))
echo ${Seeds1[0]}

for seed in "${Seeds1[@]}"
do
    echo $seed
done