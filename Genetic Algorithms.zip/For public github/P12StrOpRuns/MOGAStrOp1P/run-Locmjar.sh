#!/bin/bash

playerA="$1"
playerB="$2"
Seed1=$3
Seed2=$4



test=$(java \
    --add-opens java.base/java.lang=ALL-UNNAMED \
    -jar "./LoCM.jar" \
    -p1 "$playerA" \
    -p2 "$playerB" \
    -l /dev/stdout \
    -d "draftChoicesSeed=$Seed1 seed=$Seed2 shufflePlayer0Seed=$Seed2 shufflePlayer1Seed=$Seed2" \
    | awk 1 ORS=' ' \
    | sed 's/WARNING: sun.reflect.Reflection.getCallerClass is not supported. This will impact performance. //' -
        echo)

echo $test