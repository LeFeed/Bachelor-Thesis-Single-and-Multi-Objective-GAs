#!/bin/bash

#script to start the GA, we will initialize a Random Population, then run games to get the win-rate (fitness) and then 
#evolve the population
#1st param will be the amounts of generations to evolve, 
#2nd = size of the Population
#3rd = amount of games to play to calculate the win-rate 
echo "startdate: "$(date)
startdate=$(date)
starttime=`date +%s`
echo "starttime: "$starttime

#clean old population if there are any remains
echo $(python3 "./clean.py3")



generations=$1
populationSize=$2
numOfGames=$3
mix_rate=$4
mutation_rate=$5
crossover_rate=$6
elitism_size=$7
secondsLimit=$8 #3 hours = 10800 seconds

echo "Input Variables: "
echo "Generations: "$generations 
echo "populationSize: "$populationSize 
echo "numOfGames: "$numOfGames 
echo "mix_rate: "$mix_rate 
echo "mutation_rate: "$mutation_rate 
echo "crossover_rate: "$crossover_rate 
echo "elitism_size: "$elitism_size
echo "secondsLimit: "$secondsLimit



#TODO: these Maybe also as parameters?
agentTrain="python3 players/GAReGr/agent.py "
opponent="python3 players/ReinforcedGreediness/agent.py"


#we need an additional json to store the win-rates(fitness) of all individuals in the Pop
$(python3 "./FitnessInit.py3" $populationSize)

#after Initializing, calculate the fitness of these Populations right away


echo "init and evaluate our population.."
echo -e "\n"

for ((i=1; i<=$populationSize;i++))
do
    $(python3 "./PopInit.py3" $i)
done
echo $("./test-run-games.sh" $numOfGames "$agentTrain" "$opponent" $populationSize 0)


echo "PopInit finished!"
echo -e "\n"



#now perform Selection, Crossover, Mutation and Evaluation of the Fitness
for ((i=1; i<=$generations;i++))
do

    echo "Evolve in $i th generation.."
    echo -e "\n"

    #Evolve the Population (Produce offspring)
    echo $(python3 "./Evolve.py3" $populationSize $mix_rate $mutation_rate $crossover_rate $elitism_size )
    echo "Evolution finished!"
    echo -e "\n"

    #Evaluate the Offsprings' Fitness

    #play "numOfGames" games to calculate the win-rate (fitness) of each Individual in the Population
    #play half of the games as p1 and the other half as p2

    #use same seeds for every Gen, so that they will be tested with the same drafts and games
    
    echo $("./test-run-games.sh" $numOfGames "$agentTrain" "$opponent" $populationSize 0)






    #Sort the Population according to fitness
    
    echo $(python3 "./sortFitness.py3" $populationSize $((i)))
    echo -e "\n"

    #check if time limit was overstepped
    endtime=`date +%s`
    execution_seconds=$(($endtime - $starttime))
    if [[ $execution_seconds -gt $secondsLimit ]]; then
        echo "$secondsLimit seconds limit passed! Stop loop, no new generations"
        generations=$i
        break
    fi

done

enddate=$(date)


#save our chromosomes and clean our GA directory
echo $(python3 "./saveAndClean.py3" "$startdate" "$enddate" $generations $populationSize $numOfGames $mix_rate $mutation_rate $crossover_rate $elitism_size)
echo "\n"
#save our best value according to the 3 best chromosome generation
echo $(python3 "./helperScripts/getBestMeansTopX.py3" 3 $generations "/home/feed/Documents/BA Stuff/Simulation Stuff/git init here/BARepo/EACode/savedRuns/$startdate")

echo "startdate: "$startdate
echo "enddate: "$(date)

echo Execution time was `expr $endtime - $starttime` seconds.
