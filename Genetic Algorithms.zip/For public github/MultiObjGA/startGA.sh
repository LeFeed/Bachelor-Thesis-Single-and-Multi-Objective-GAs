#!/bin/bash

#example start: 
#startGA.sh generations pop_size games mix_rate mutation_rate crossover_rate elitism_size SECONDS_LIMIT
#startGA.sh 1 10 20 0.5 0.05 0.7 0.5 1000


#script to start the GA, we will initialize a Random Population, then run games to get the win-rate (fitness) and then 
#evolve the population
#1st param will be the amounts of generations to evolve, 
#2nd = size of the Population
#3rd = amount of games to play to calculate the win-rate 
echo "startdate: "$(date)
startdate=$(date)
starttime=`date +%s`
echo "starttime: "$starttime

# multiObjPath="."

# START WITH THIS 14.07: ./startGA.sh 44 29 52 0.17072185161279574 0.09989773401317525 0.6497074706854404 345600 > runLogs.txt

#./startGA.sh 44 29 52 0.17072185161279574 0.09989773401317525 0.6497074706854404 345600 > runLogs.txt

#(345600 sekunden sind 4 Tage bzw. 96)
#nur 44 generationen erstmal! Um ähnlich zu singleobj zu verfahren

#clean old population if there are any remains
echo $(python3 "./clean.py3")


generations=$1
populationSize=$2
numOfGames=$3
mix_rate=$4
mutation_rate=$5
crossover_rate=$6
#Elitism is fixed here!
elitism_size=1
secondsLimit=$7 #3 hours = 10800 seconds

echo "Input Variables: "
echo "Generations: "$generations 
echo "populationSize: "$populationSize 
echo "numOfGames: "$numOfGames 
echo "mix_rate: "$mix_rate 
echo "mutation_rate: "$mutation_rate 
echo "crossover_rate: "$crossover_rate 
echo "elitism_size: "$elitism_size
echo "secondsLimit: "$secondsLimit



#TODO: these Maybe also as parameters?
agentTrain="python3 players/GAReGr/agent.py "
opponent="python3 players/ReinforcedGreediness/agent.py"

#we need an additional json to store the win-rates(fitness) of all individuals in the Pop
$(python3 "FitnessInit.py3" $populationSize)

#Initialize our population randomly, then calculate the fitness of these Populations right away
echo "init and evaluate our population.."
echo -e "\n"

for ((i=1; i<=$populationSize;i++))
do
    $(python3 "PopInit.py3" $i)
done
echo $("./test-run-games.sh" $numOfGames "$agentTrain" "$opponent" $populationSize 0)

echo "PopInit finished!"
echo -e "\n"

#nondominational sort/rank the population in Fronts and with crowding distance assignment
echo $(python3 "helperScripts/nondominationSort.py3")



#now perform Selection, Crossover, Mutation and Evaluation of the Fitness
for ((i=1; i<=$generations;i++))
do

    echo "Evolve in $i th generation.."
    echo -e "\n"

    #Evolve the Population (Produce offspring)
    echo $(python3 "Evolve.py3" $populationSize $mix_rate $mutation_rate $crossover_rate $elitism_size )
    echo "Evolution finished!"
    echo -e "\n"

    #Evaluate the Offsprings' Fitness

    #play "numOfGames" games to calculate the win-rate (fitness) of each Individual in the Population
    #play half of the games as p1 and the other half as p2

    #use same seeds for every Gen, so that they will be tested with the same drafts and games
    echo "Evaluate with games now"
    echo $("./test-run-games.sh" $numOfGames "$agentTrain" "$opponent" $populationSize 0)
    echo "Evaluation finished!"




    

    #Sort the Population according to fitness
    #echo $(python3 "$sortFitness.py3" $populationSize $((i)))
    
    #echo -e "\n"
    #sleep 100
    echo "nondomination Sort now!"
    echo $(python3 "helperScripts/nondominationSort.py3")


    echo "nondomination Finished!"
    echo "save population now to old!"

    echo $(python3 "helperScripts/savePopulation.py3" $((i)))
    echo "pops saved!"

    echo "sort the fronts now for the Evolve script!"
    
    #Script that cuts down the population according to best fronts/crowding distance to popSize
    # AND save the front ordered Population


    echo $(python3 "helperScripts/sortFronts.py3" $populationSize $((i)))
    echo "Fronts sorted. If timelimit not overstepped, restart loop"

    #check if time limit was overstepped
    endtime=`date +%s`
    execution_seconds=$(($endtime - $starttime))
    if [[ $execution_seconds -gt $secondsLimit ]]; then
        echo "$secondsLimit seconds limit passed! Stop loop, no new generations"
        generations=$i
        break
    fi

done

enddate=$(date)

#save our chromosomes and clean our GA directory
#echo $(python3 "./saveAndClean.py3" "$startdate" "$enddate" $generations $populationSize $numOfGames $mix_rate $mutation_rate $crossover_rate $elitism_size)
echo "\n"
#save our best value according to the 3 best chromosome generation
#echo $(python3 "$helperScripts/getBestMeansTopX.py3" 1 $generations "/home/feed/Documents/BA Stuff/Simulation Stuff/git init here/BARepo/EACode/savedRuns/multiObjRuns/$startdate")

echo "startdate: "$startdate
echo "enddate: "$(date)

echo Execution time: `expr $endtime - $starttime` seconds.
