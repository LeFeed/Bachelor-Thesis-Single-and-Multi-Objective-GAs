#!/bin/bash

numOfGames=$1
playerA="$2"
playerB="$3"
populationSize=$4

multiObjPath="."
#"popNum" only used to differentiate between GA Use and Single Individual Testing
#should be 0 if used in GA, otherwise should be X in "PopulationX.json" of the individual you wanna use
popNum=$5



winsAsP1=0
winsAsP2=0
Seeds1=($(python3 "$multiObjPath/helperScripts/generateSeeds.py3" $(($numOfGames)) | tr -d '[],'))
Seeds2=($(python3 "$multiObjPath/helperScripts/generateSeeds.py3" $(($numOfGames)) | tr -d '[],'))

populationSize=($(python3 "$multiObjPath/helperScripts/getFitnessSize.py3"))
echo $populationSize


for ((i=1; i<=$populationSize;i++))
do

    #reset logs again for each Chromosome
    $(python3 helperScripts/cleanLogs.py3)

    echo "start tests as P1"
    if [[ $popNum -ne 0 ]]; then
        i=$popNum
        populationSize=0
    fi

    j=0
    winsAsP1=0
    winsAsP2=0
    limit=$(($numOfGames/2))

    #run the games as P1

    #in case we dont have games that should be handled by a multiplication of 4 (we use 4 threads)
    oddGames=$(($limit%4))

    #echo "oddgames:"
    #echo $oddGames
    
    if [[ $oddGames -ne 0 ]]; then
        while [ $j -lt $oddGames ];do
            source "$multiObjPath/run-Locmjar.sh" "$playerA$i" "$playerB" ${Seeds1[$j]} ${Seeds2[$j]} >> "$multiObjPath/logs/P1logs1.txt" &
            wait
            wins1=$(cat "$multiObjPath/logs/P1logs1.txt" | grep -c "0 won")
            echo "G:"
            echo $wins1
            winsAsP1=$(($winsAsP1+${wins1}))
            ((j++))
        done
    fi
    #echo "oddgames have been played. j: "
    #echo $j
    echo "wins so far: "
    echo $winsAsP1
    
    echo "main run:"
    #our main loop for the games with 4 threads
    while [ $j -lt $limit ];do

        #we run 4 instances at the same time, after testing this is the most efficient for the local pc
        source "$multiObjPath/run-Locmjar.sh" "$playerA$i" "$playerB" ${Seeds1[$j]} ${Seeds2[$j]} >> "$multiObjPath/logs/P1logs1.txt" &
        source "$multiObjPath/run-Locmjar.sh" "$playerA$i" "$playerB" ${Seeds1[$j+1]} ${Seeds2[$j+1]} >> "$multiObjPath/logs/P1logs2.txt" &
        source "$multiObjPath/run-Locmjar.sh" "$playerA$i" "$playerB" ${Seeds1[$j+2]} ${Seeds2[$j+2]} >> "$multiObjPath/logs/P1logs3.txt" &
        source "$multiObjPath/run-Locmjar.sh" "$playerA$i" "$playerB" ${Seeds1[$j+3]} ${Seeds2[$j+3]} >> "$multiObjPath/logs/P1logs4.txt" &
        wait
        
        #should return 1, if player A ("Player 0" in the logs has won
        wins1=$(cat "$multiObjPath/logs/P1logs1.txt" | grep -c "0 won")
        echo "G:"
        echo $wins1
        wins2=$(cat "$multiObjPath/logs/P1logs2.txt" | grep -c "0 won")
        echo "G:"
        echo $wins2
        wins3=$(cat "$multiObjPath/logs/P1logs3.txt" | grep -c "0 won")
        echo "G:"
        echo $wins3
        wins4=$(cat "$multiObjPath/logs/P1logs4.txt" | grep -c "0 won")
        echo "G:"
        echo $wins4

        #TODO: implement analyze for our logs (winrates and mana curve, maybe additional data)
        

        winsAsP1=$((${wins1}+${wins2}+${wins3}+${wins4}))

        j=$(($j+4))
    done


    echo "P1 wins summed up:"
    echo $winsAsP1 
    echo
    #echo "j: "
    #echo $j


    limit=$numOfGames


    #run the games as P2
    #in case we dont have games that should be handled by a multiplication of 4 (we use 4 threads)
    #echo "oddgames:"
    #echo $oddGames
    jTemp=$j

    if [[ $oddGames -ne 0 ]]; then
        while [ $j -lt $(($oddGames+$jTemp)) ];do
            source "$multiObjPath/run-Locmjar.sh" "$playerB" "$playerA$i"  ${Seeds1[$j]} ${Seeds2[$j]} >> "$multiObjPath/logs/P2logs1.txt" &
            wait
            wins1=$(cat "$multiObjPath/logs/P2logs1.txt" | grep -c "1 won")
            echo "G:"
            echo $wins1
            winsAsP2=$(($winsAsP2+${wins1}))
            ((j++))
        done
    fi
    #echo "oddgames have been played. j: "
    #echo $j
    echo "wins so far: "
    echo $winsAsP2
    
    echo "main run:"
    #our main loop for the games with 4 threads
    while [ $j -lt $limit ];do

        #we run 4 instances at the same time, after testing this is the most efficient for the local pc
        source "$multiObjPath/run-Locmjar.sh" "$playerB" "$playerA$i" ${Seeds1[$j]} ${Seeds2[$j]} >> "$multiObjPath/logs/P2logs1.txt" &
        source "$multiObjPath/run-Locmjar.sh" "$playerB" "$playerA$i" ${Seeds1[$j+1]} ${Seeds2[$j+1]} >> "$multiObjPath/logs/P2logs2.txt" &
        source "$multiObjPath/run-Locmjar.sh" "$playerB" "$playerA$i" ${Seeds1[$j+2]} ${Seeds2[$j+2]} >> "$multiObjPath/logs/P2logs3.txt" &
        source "$multiObjPath/run-Locmjar.sh" "$playerB" "$playerA$i" ${Seeds1[$j+3]} ${Seeds2[$j+3]} >> "$multiObjPath/logs/P2logs4.txt" &
        wait
        
        #should return 1, if player B ("Player 1" in the logs) has won
        wins1=$(cat "$multiObjPath/logs/P2logs1.txt" | grep -c "1 won")
        echo "G:"
        echo $wins1
        wins2=$(cat "$multiObjPath/logs/P2logs2.txt" | grep -c "1 won")
        echo "G:"
        echo $wins2
        wins3=$(cat "$multiObjPath/logs/P2logs3.txt" | grep -c "1 won")
        echo "G:"
        echo $wins3
        wins4=$(cat "$multiObjPath/logs/P2logs4.txt" | grep -c "1 won")
        echo "G:"
        echo $wins4

        #TODO: implement analyze for our logs (winrates and mana curve, maybe additional data)
        

        winsAsP2=$((${wins1}+${wins2}+${wins3}+${wins4}))

        j=$(($j+4))
    done

    echo "P2 wins summed up:"
    echo $winsAsP2 
    echo
    #echo "j: "
    #echo $j
    



    #echo $wins
    #echo $numOfGames
    #echo "scale=2 ; $wins / $numOfGames" | bc

    #storeTheFitness of the Individual for the i-th Population

    echo
    echo $(python3 "$multiObjPath/helperScripts/extractManaFitness.py3" $i)
    echo $(python3 "$multiObjPath/storeFitness.py3" $winsAsP1 $winsAsP2 $numOfGames $i)
    echo
done













